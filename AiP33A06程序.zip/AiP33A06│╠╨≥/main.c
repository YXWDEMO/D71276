#include "AiP33A06.h"
void main()
{
	P3 =0XFF;
	P3IO=0XFF;
	Ram_Clear();
	sysinit();
	while(1)
	{
		display();
		delay_ms(100);
	}
}